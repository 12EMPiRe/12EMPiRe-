-- Run this in Supabase SQL Editor. Review policies before production launch.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'Apparel',
  description text not null default '',
  price_cents integer not null check (price_cents >= 0),
  image_url text,
  stock integer not null default 0 check (stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  starts_at timestamptz,
  venue text,
  ticket_price_cents integer not null default 0 check (ticket_price_cents >= 0),
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  stripe_session_id text unique,
  status text not null default 'pending' check (status in ('pending','paid','cancelled','refunded')),
  currency text not null default 'usd',
  total_cents integer not null default 0 check (total_cents >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price_cents integer not null check (unit_price_cents >= 0)
);

create table if not exists public.event_bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  event_id uuid not null references public.events(id) on delete cascade,
  quantity integer not null default 1 check (quantity between 1 and 10),
  status text not null default 'pending' check (status in ('pending','confirmed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.community_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.business_enquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  contact text not null,
  topic text not null,
  message text not null,
  status text not null default 'new' check (status in ('new','reviewing','closed')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.events enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.event_bookings enable row level security;
alter table public.community_posts enable row level security;
alter table public.business_enquiries enable row level security;

-- Public users can view only active products and published events.
create policy "Public can view active products" on public.products for select using (active = true);
create policy "Public can view published events" on public.events for select using (published = true);
create policy "Public can view published community posts" on public.community_posts for select using (published = true);
create policy "Members can create own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Members can view own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Members can update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Members can create posts" on public.community_posts for insert to authenticated with check (auth.uid() = user_id);
create policy "Members can manage own posts" on public.community_posts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Members can delete own posts" on public.community_posts for delete to authenticated using (auth.uid() = user_id);
create policy "Members can view own bookings" on public.event_bookings for select to authenticated using (auth.uid() = user_id);
create policy "Members can create own bookings" on public.event_bookings for insert to authenticated with check (auth.uid() = user_id);
create policy "Members can view own orders" on public.orders for select to authenticated using (auth.uid() = user_id);
create policy "Members can view own order items" on public.order_items for select to authenticated using (exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
-- No public insert policy for orders or enquiries: use validated server endpoints to avoid spam/forgery.
-- Admin operations must be implemented server-side and must verify role/authorization.
