import Stripe from 'stripe';
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const secret = process.env.STRIPE_SECRET_KEY;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret || !webhookSecret) return NextResponse.json({ error: 'Webhook is not configured.' }, { status: 503 });
  const stripe = new Stripe(secret);
  const signature = request.headers.get('stripe-signature');
  if (!signature) return NextResponse.json({ error: 'Missing signature.' }, { status: 400 });
  const raw = await request.text();
  let event: Stripe.Event;
  try { event = stripe.webhooks.constructEvent(raw, signature, webhookSecret); }
  catch { return NextResponse.json({ error: 'Invalid signature.' }, { status: 400 }); }
  // TODO: On checkout.session.completed, persist the order to Supabase and trigger receipt fulfilment.
  // Do not mark orders paid from the browser redirect; only trust verified webhook events.
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    console.info('Verified completed checkout:', session.id);
  }
  return NextResponse.json({ received: true });
}
