import Stripe from 'stripe';
import { NextResponse } from 'next/server';
import { getSupabase } from '../../../lib/supabase';

export async function POST(request: Request) {
  const secret = process.env.STRIPE_SECRET_KEY;
  const site = process.env.NEXT_PUBLIC_SITE_URL;
  if (!secret || !site) return NextResponse.json({ error: 'Payments are not configured yet.' }, { status: 503 });
  try {
    const body = await request.json() as { items?: { productId: string; quantity: number }[] };
    if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 30) return NextResponse.json({ error: 'Invalid cart.' }, { status: 400 });
    const quantities = new Map<string, number>();
    for (const item of body.items) {
      if (!item || typeof item.productId !== 'string' || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 10) return NextResponse.json({ error: 'Invalid cart item.' }, { status: 400 });
      quantities.set(item.productId, (quantities.get(item.productId) ?? 0) + item.quantity);
    }
    const supabase = getSupabase();
    const ids = [...quantities.keys()];
    const { data, error } = await supabase.from('products').select('id,name,price_cents,active').in('id', ids).eq('active', true);
    if (error || !data || data.length !== ids.length) return NextResponse.json({ error: 'One or more products are unavailable.' }, { status: 400 });
    const stripe = new Stripe(secret);
    const session = await stripe.checkout.sessions.create({ mode: 'payment', line_items: data.map(p => ({ quantity: quantities.get(p.id)!, price_data: { currency: 'usd', unit_amount: p.price_cents, product_data: { name: p.name } } })), success_url: `${site}/?checkout=success`, cancel_url: `${site}/?checkout=cancelled`, metadata: { source: '12-empire-web' } });
    return NextResponse.json({ url: session.url });
  } catch { return NextResponse.json({ error: 'Unable to create checkout session.' }, { status: 500 }); }
}
