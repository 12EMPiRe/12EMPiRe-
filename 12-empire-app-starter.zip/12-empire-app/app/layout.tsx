import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = { title: '12 EMPIRE | Dream. Build. Empire.', description: 'Official 12 EMPIRE shop, events, and community.', manifest: '/manifest.json', applicationName: '12 EMPIRE', appleWebApp: { capable: true, statusBarStyle: 'black-translucent', title: '12 EMPIRE' } };
export const viewport: Viewport = { themeColor: '#090909', width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
