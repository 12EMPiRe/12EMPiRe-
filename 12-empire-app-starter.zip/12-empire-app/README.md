# 12 EMPIRE — real-app starter

A responsive Next.js app starter using the black-and-gold 12 EMPIRE identity. Includes a storefront shell, event/community/business sections, Supabase database schema, and a server-side Stripe Checkout session endpoint with signature-verified webhook scaffold.

## What this is — and is not

This is a deployable **starter project**, not a finished production service. It has not been deployed, and real checkout, accounts, orders, event ticketing, community moderation, and admin tools are not enabled until configured and tested. The homepage uses sample products when Supabase is not configured. Sample prices are placeholders.

## Requirements

- Node.js 20+
- A Supabase project (database and authentication)
- A Stripe account (start in test mode)
- A deployment provider that supports Next.js, such as Vercel

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env.local` and fill in your Supabase and Stripe values.
3. In a terminal, run `npm install` then `npm run dev`.
4. Open `http://localhost:3000`.

The homepage can be previewed with sample products without Supabase; checkout intentionally returns an error until Stripe and Supabase are configured.

## Configure Supabase

1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Add the project URL and anon key to `.env.local`.
4. Keep `SUPABASE_SERVICE_ROLE_KEY` server-only if you later add admin jobs; never expose it in browser code.
5. Add products in the `products` table. Store prices as integer cents (e.g. $25.00 = `2500`).
6. Review and extend Row Level Security policies before launch. Create a carefully protected admin workflow before managing products/orders from the browser.

## Configure Stripe

1. Start in Stripe test mode.
2. Put the test secret key in `STRIPE_SECRET_KEY`.
3. Set `NEXT_PUBLIC_SITE_URL` to your local URL for testing, then your HTTPS domain after deployment.
4. Register a webhook endpoint at `/api/webhook` and subscribe to `checkout.session.completed`; set its signing secret as `STRIPE_WEBHOOK_SECRET`.
5. Before taking real payments, implement persistent order creation and inventory reservation in the verified webhook handler, plus shipping/tax/refund workflows and testing. The webhook currently verifies events but does not persist orders.
6. Do not enable live mode until test purchases and webhook retries are verified.

## Deploy

1. Push this folder to a private Git repository.
2. Import it into a Next.js-capable host such as Vercel.
3. Add environment variables from `.env.example` in the host settings.
4. Deploy with HTTPS and test authentication, catalog, webhook signatures, privacy, and checkout.
5. Add your real logo asset to `public/` and replace the temporary text/crown mark in the header. Generate actual PWA icons and update `public/manifest.json` before app-store or installable-PWA release.

## Important production work remaining

- Implement Supabase sign-up/sign-in, password recovery, and account screens.
- Add validated business enquiry submission with rate limiting and spam protection.
- Implement ticket inventory, booking confirmation, QR tickets, and refunds.
- Implement real community profiles, moderation/reporting, and pagination.
- Implement a role-checked admin dashboard; never rely on a client-side role check alone.
- Persist orders from verified Stripe webhooks; reconcile inventory safely and handle duplicate webhook deliveries idempotently.
- Add legal business details, terms, privacy/returns policies, shipping/tax rules, monitoring, backups, and accessibility checks.

## Security notes

Never commit `.env.local`. Never expose Stripe secret keys or Supabase service-role keys in browser code. Checkout prices are read from the database, not accepted from the client. The webhook validates Stripe's signature. This starter still requires a security review before production.
