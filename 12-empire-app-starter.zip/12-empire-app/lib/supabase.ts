import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export function getSupabase() {
  if (!url || !key) throw new Error('Supabase is not configured. Add the environment variables from .env.example.');
  return createClient(url, key, { auth: { persistSession: false } });
}
