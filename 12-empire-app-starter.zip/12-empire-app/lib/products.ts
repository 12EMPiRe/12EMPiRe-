export type Product = { id: string; name: string; category: string; price_cents: number; description: string; image_url?: string | null; active: boolean };

// Public catalog reads from Supabase once configured. Never trust client-submitted prices at checkout.
export async function getProducts(): Promise<Product[]> {
  const { getSupabase } = await import('./supabase');
  const supabase = getSupabase();
  const { data, error } = await supabase.from('products').select('id,name,category,price_cents,description,image_url,active').eq('active', true).order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as Product[];
}
